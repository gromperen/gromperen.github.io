# Multiplicative convolution modulo M

Code for the blog post *Fast multiplicative convolution modulo a composite number*.
Given arrays `f`, `g` indexed by the residues mod `M`, it computes

    h[z] = sum over x*y ≡ z (mod M) of f[x] * g[y]

for every `z`, in O(M log M) arithmetic operations.

## Files

| File | Contents |
| --- | --- |
| `exact_fourier.hpp` | Number-theoretic transforms over prime fields (radix 2, small direct DFTs, Bluestein). |
| `exact_product.hpp` | The block transform and multiplication, the shell-pair baseline, and exact signed reconstruction by CRT. |
| `exact_product.cpp` | Command-line driver: self-test, benchmark, and a `--convolve` mode. |
| `multiplicative_convolution.py` | A NumPy prototype that uses floating-point FFTs. |
| `shell_pairs.py` | The shell-pair baseline in NumPy, for comparison with the prototype. |

## C++ (exact integer arithmetic)

Requires a C++20 compiler with `__int128` (Clang or GCC).

```sh
clang++ -O3 -std=c++20 -Wall -Wextra exact_product.cpp -o exact_product
./exact_product --self-test      # checks 262 moduli against direct enumeration
./exact_product --bench          # timings used in the post
printf '%s\n' '0 3 2 0' '0 4 1 0' | ./exact_product --convolve 4   # prints: 2 12 11 0
```

`--convolve M` reads two whitespace-separated vectors of `M` signed 32-bit integers,
each in residue order `0, 1, ..., M-1`, and prints `h` in the same order.

## Python prototype

Requires NumPy.

```sh
python multiplicative_convolution.py --max-small 256 --repeat 3
python shell_pairs.py
```

```python
from multiplicative_convolution import ModularProduct

plan = ModularProduct(12)
h = plan.multiply(f, g)   # f, g: length-12 arrays
```
